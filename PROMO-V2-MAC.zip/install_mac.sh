#!/bin/bash
echo "========================================="
echo "  ROAV TG-Boost - Mac Setup Script"
echo "========================================="
echo ""

if ! command -v python3 &> /dev/null
then
    echo "❌ Python3 is not installed on your Mac."
    echo "Please download and install Python from https://www.python.org/downloads/mac-osx/"
    echo "Or install via Homebrew: brew install python"
    echo "Press Enter to exit..."
    read
    exit 1
fi

echo "✅ Python3 detected. Installing required libraries..."
python3 -m pip install --upgrade pip
python3 -m pip install -r requirements.txt

echo ""
echo "✅ Installation Complete! You can now launch the software by running: ./run_mac.sh"
echo "Press Enter to close..."
read
