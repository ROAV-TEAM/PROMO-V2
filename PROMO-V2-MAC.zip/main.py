import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import webview
import json
import requests
import requests
import asyncio
import threading
import webbrowser
from telegram_manager import TelegramManager

ADMIN_SERVER_URL = 'https://promoserver.vercel.app'
CURRENT_VERSION = '2.0'
tg_manager = TelegramManager()

def get_hwid():
    """Generates a Hardware ID based on the OS"""
    import platform
    import subprocess
    import uuid
    try:
        if platform.system() == "Windows":
            import wmi
            c = wmi.WMI()
            return c.Win32_ComputerSystemProduct()[0].UUID
        elif platform.system() == "Darwin": # macOS
            output = subprocess.check_output(
                ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"]
            ).decode("utf-8")
            for line in output.split('\n'):
                if "IOPlatformUUID" in line:
                    return line.split("=")[1].strip().strip('"')
            return str(uuid.getnode())
        else:
            return str(uuid.getnode())
    except Exception:
        return str(uuid.getnode())

class Api:
    def __init__(self):
        self.window = None

    def validate_license(self, key):
        hwid = get_hwid()
        try:
            response = requests.post(
                f"{ADMIN_SERVER_URL}/api/validate_key", 
                data={'key': key, 'hwid': hwid, 'version': CURRENT_VERSION}, 
                timeout=5
            )
            data = response.json()
            if response.status_code == 200:
                if data.get('status') == 'success':
                    return {'success': True, 'message': data.get('message'), 'expires_in': data.get('expires_in_days')}
                elif data.get('status') == 'update_required':
                    return {'success': False, 'is_update': True, 'message': data.get('message'), 'url': data.get('url')}
            return {'success': False, 'message': data.get('detail', 'Invalid Key')}
        except requests.exceptions.RequestException as e:
            return {'success': False, 'message': f"Server connection failed: {str(e)}"}

    def send_otp(self, phone_number):
        return tg_manager.run_sync(tg_manager.send_otp(phone_number))

    def verify_otp(self, phone_number, otp):
        return tg_manager.run_sync(tg_manager.verify_otp(phone_number, otp))

    def verify_2fa(self, phone_number, password):
        return tg_manager.run_sync(tg_manager.verify_2fa(phone_number, password))

    def get_logged_in_accounts(self):
        return tg_manager.get_session_list()

    def delete_account(self, phone_number):
        return tg_manager.delete_session(phone_number)

    def fetch_groups_from_account(self, phone_number):
        try:
            groups = tg_manager.run_sync(tg_manager.get_dialogs(phone_number))
            tg_manager.execute_js(f"on_groups_fetched({json.dumps({'phone': phone_number, 'data': groups})})")
        except Exception as e:
            tg_manager.execute_js(f"on_groups_fetched({json.dumps({'phone': phone_number, 'data': [], 'error': str(e)})})")

    def start_broadcast(self, target_group_ids, message_text_1, message_text_2, delay_seconds, auto_repeat, repeat_interval=300):
        if not tg_manager.clients:
            return {'success': False, 'message': 'No active accounts to send from.'}
        threading.Thread(
            target=tg_manager.run_broadcast_sync, 
            args=(target_group_ids, message_text_1, message_text_2, int(delay_seconds), auto_repeat, int(repeat_interval)), 
            daemon=True
        ).start()
        return {'success': True, 'message': 'Broadcast started.'}

    def stop_broadcast(self):
        tg_manager.stop_broadcast()
        return {'success': True, 'message': 'Stopping broadcast...'}

    def fetch_app_data(self):
        try:
            response = requests.get(f"{ADMIN_SERVER_URL}/api/data", timeout=5)
            if response.status_code == 200:
                return {'success': True, 'data': response.json()}
            return {'success': False, 'message': 'Admin server responded with error.'}
        except requests.exceptions.RequestException:
            return {'success': False, 'message': 'Failed to connect to Admin Server.'}

    def join_target_groups(self, links_array, join_count):
        if not tg_manager.clients:
            return {'success': False, 'message': 'No active accounts to join from.'}
        threading.Thread(
            target=tg_manager.run_join_groups, 
            args=(links_array, join_count), 
            daemon=True
        ).start()
        return {'success': True, 'message': 'Mass Join started.'}

    def open_browser(self, url):
        webbrowser.open(url)


if __name__ == '__main__':
    import datetime
    log_file = 'autosender_debug.log'
    
    def log_debug(msg):
        timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print(f"[{timestamp}] {msg}")
        try:
            with open(log_file, 'a', encoding='utf-8') as f:
                f.write(f"[{timestamp}] {msg}\n")
        except Exception:
            pass

    log_debug('Starting AutoSender App...')
    log_debug('Loading UI from: ui/index.html')
    
    try:
        
        api = Api()
        ui_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ui', 'index.html')
        window = webview.create_window('ROAV – TG Boost', ui_path, js_api=api, width=1200, height=800, resizable=True)
        api.window = window
        tg_manager.set_window(window)
        webview.start(debug=False)
    except (SystemExit, MemoryError, KeyboardInterrupt):
        log_debug('App terminated.')
    except FileNotFoundError as e:
        log_debug(f"ERROR - File not found: {e}")
        log_debug("Make sure 'ui' folder with 'index.html' exists in the same directory")
    except Exception as e:
        log_debug(f"ERROR - Failed to start Eel: {type(e).__name__}: {e}")
        import traceback
        log_debug(traceback.format_exc())
