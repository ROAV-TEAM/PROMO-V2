#!/bin/bash
echo "Starting ROAV TG-Boost..."
python3 main.py
